// ПУТЬ: com/studyflow/app/ui/theme/Theme.kt

package com.studyflow.app.ui.theme

import android.app.Activity
import android.content.Context
import android.content.ContextWrapper
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Typography
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.SideEffect
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.view.WindowCompat
import com.studyflow.app.domain.model.CognitiveTier

/**
 * Палитра и материалы StudyFlow:
 * Linear (Light Mode) + холодный серо-белый металл + хирургический Liquid Glass.
 */
object StudyFlowColors {
    // Холодный металлический холст
    val CanvasTop = Color(0xFFF7F8FA)
    val CanvasMid = Color(0xFFEFF1F5)
    val CanvasBottom = Color(0xFFE8ECF1)

    // Холодный серебристый холст для фазы отдыха
    val BreakCanvasTop = Color(0xFFF1F5F4)
    val BreakCanvasBottom = Color(0xFFE6ECEB)

    // Матовые металлические поверхности
    val MetalSurfaceTop = Color(0xFFFFFFFF)
    val MetalSurfaceBottom = Color(0xFFF3F5F8)
    val MetalBorderTop = Color(0xFFFFFFFF)
    val MetalBorderBottom = Color(0xFFD4DAE3)
    val AmbientShadow = Color(0xFF0F172A)

    // Сегментированный трек и прогресс-треки
    val SegmentedTrack = Color(0xFFE2E6ED)
    val ProgressTrack = Color(0xFFDCE1E9)
    val PlayRingBorder = Color(0xFFCBD5E1)
    val HairlineDivider = Color(0xFFDFE4EC)
    val SheetRowDivider = Color(0xFFE2E7F0)

    // Типографика
    val InkGraphite = Color(0xFF0F172A)
    val SlateSecondary = Color(0xFF64748B)
    val SilverMuted = Color(0xFF94A3B8)

    // Микро-акценты сложности (только 6.dp точки и 2.dp линии)
    val LoadHardAccent = Color(0xFF3730A3)
    val LoadPracticeAccent = Color(0xFFB45309)
    val LoadLightAccent = Color(0xFF047857)

    // Аккуратный оттенок для деструктивных действий
    val DangerInk = Color(0xFFB91C1C)
}

/**
 * Единый фоновый модификатор холодного серо-белого матового металла
 * с деликатным верхним световым бликом.
 */
fun Modifier.metallicCanvasBackground(isBreakMode: Boolean = false): Modifier = this.drawBehind {
    val baseColors = if (isBreakMode) {
        listOf(StudyFlowColors.BreakCanvasTop, StudyFlowColors.BreakCanvasBottom)
    } else {
        listOf(
            StudyFlowColors.CanvasTop,
            StudyFlowColors.CanvasMid,
            StudyFlowColors.CanvasBottom
        )
    }

    drawRect(
        brush = Brush.verticalGradient(colors = baseColors)
    )

    // Деликатный верхний световой блик
    drawRect(
        brush = Brush.radialGradient(
            colors = listOf(
                Color.White.copy(alpha = if (isBreakMode) 0.55f else 0.85f),
                Color.Transparent
            ),
            center = Offset(size.width * 0.5f, 0f),
            radius = size.width * 0.95f
        )
    )
}

/**
 * Матовая серо-белая металлическая поверхность с микроградиентом (#FFFFFF -> #F3F5F8),
 * фаской 0.75.dp (белый верхний блик, холодная сталь снизу) и мягкой тенью.
 */
@Composable
fun MetallicSurface(
    modifier: Modifier = Modifier,
    shape: Shape = RoundedCornerShape(20.dp),
    content: @Composable BoxScope.() -> Unit
) {
    val fillBrush = Brush.verticalGradient(
        colors = listOf(
            StudyFlowColors.MetalSurfaceTop,
            StudyFlowColors.MetalSurfaceBottom
        )
    )
    val bevelBrush = Brush.verticalGradient(
        colors = listOf(
            StudyFlowColors.MetalBorderTop,
            StudyFlowColors.MetalBorderBottom
        )
    )

    Box(
        modifier = modifier
            .shadow(
                elevation = 1.5.dp,
                shape = shape,
                ambientColor = StudyFlowColors.AmbientShadow.copy(alpha = 0.04f),
                spotColor = StudyFlowColors.AmbientShadow.copy(alpha = 0.04f)
            )
            .clip(shape)
            .background(brush = fillBrush, shape = shape)
            .border(width = 0.75.dp, brush = bevelBrush, shape = shape),
        content = content
    )
}

/**
 * Хирургический Liquid Glass — используется точечно для плавающих контролов,
 * капсул, активной вкладки и центральной линзы таймера.
 */
@Composable
fun LiquidGlassSurface(
    modifier: Modifier = Modifier,
    shape: Shape = RoundedCornerShape(999.dp),
    content: @Composable BoxScope.() -> Unit
) {
    val glassFill = Brush.verticalGradient(
        colors = listOf(
            Color.White.copy(alpha = 0.78f),
            Color(0xFFF1F5F9).copy(alpha = 0.58f)
        )
    )
    val specularRim = Brush.verticalGradient(
        colors = listOf(
            Color.White,
            Color(0xFFCBD5E1).copy(alpha = 0.50f),
            Color.White.copy(alpha = 0.70f)
        )
    )

    Box(
        modifier = modifier
            .shadow(
                elevation = 2.dp,
                shape = shape,
                ambientColor = StudyFlowColors.AmbientShadow.copy(alpha = 0.05f),
                spotColor = StudyFlowColors.AmbientShadow.copy(alpha = 0.06f)
            )
            .drawBehind {
                // Рассеянное серебристо-стальное оптическое свечение под стеклом
                drawRect(
                    brush = Brush.radialGradient(
                        colors = listOf(
                            Color.White.copy(alpha = 0.65f),
                            Color(0xFFCBD5E1).copy(alpha = 0.22f),
                            Color.Transparent
                        ),
                        center = Offset(size.width * 0.5f, size.height * 0.5f),
                        radius = size.maxDimension * 0.65f
                    )
                )
            }
            .clip(shape)
            .background(brush = glassFill, shape = shape)
            .border(width = 0.85.dp, brush = specularRim, shape = shape),
        content = content
    )
}

/**
 * Возвращает чистый микро-акцент сложности (используется только для 6.dp точек и 2.dp линий).
 */
fun CognitiveTier.accentColor(): Color = when (this) {
    CognitiveTier.TIER_1 -> StudyFlowColors.LoadHardAccent
    CognitiveTier.TIER_2 -> StudyFlowColors.LoadPracticeAccent
    CognitiveTier.TIER_3 -> StudyFlowColors.LoadLightAccent
}

/**
 * Единственно допустимые пользовательские названия уровней нагрузки (без технического жаргона).
 */
fun CognitiveTier.cleanLabel(): String = when (this) {
    CognitiveTier.TIER_1 -> "Сложное"
    CognitiveTier.TIER_2 -> "Практика"
    CognitiveTier.TIER_3 -> "Лёгкое"
}

/**
 * Настраивает тёмные системные иконки статус-бара и навигации на светлом металлическом фоне.
 */
@Composable
fun LightSystemBarsEffect() {
    val view = LocalView.current
    if (!view.isInEditMode) {
        SideEffect {
            val activity = view.context.findActivity() ?: return@SideEffect
            val controller = WindowCompat.getInsetsController(activity.window, view)
            controller.isAppearanceLightStatusBars = true
            controller.isAppearanceLightNavigationBars = true
        }
    }
}

private tailrec fun Context.findActivity(): Activity? = when (this) {
    is Activity -> this
    is ContextWrapper -> baseContext.findActivity()
    else -> null
}

private val StudyFlowLinearColorScheme = lightColorScheme(
    primary = StudyFlowColors.InkGraphite,
    onPrimary = Color.White,
    primaryContainer = StudyFlowColors.MetalSurfaceBottom,
    onPrimaryContainer = StudyFlowColors.InkGraphite,
    secondary = StudyFlowColors.SlateSecondary,
    onSecondary = Color.White,
    secondaryContainer = StudyFlowColors.SegmentedTrack,
    onSecondaryContainer = StudyFlowColors.InkGraphite,
    background = StudyFlowColors.CanvasTop,
    onBackground = StudyFlowColors.InkGraphite,
    surface = StudyFlowColors.MetalSurfaceTop,
    onSurface = StudyFlowColors.InkGraphite,
    surfaceVariant = StudyFlowColors.MetalSurfaceBottom,
    onSurfaceVariant = StudyFlowColors.SlateSecondary,
    outline = StudyFlowColors.MetalBorderBottom,
    outlineVariant = StudyFlowColors.HairlineDivider,
    error = StudyFlowColors.DangerInk,
    onError = Color.White
)

private val StudyFlowTypography = Typography(
    displayLarge = TextStyle(
        fontWeight = FontWeight.Normal,
        fontSize = 56.sp,
        lineHeight = 62.sp,
        letterSpacing = (-2.0).sp,
        fontFeatureSettings = "tnum"
    ),
    displayMedium = TextStyle(
        fontWeight = FontWeight.Medium,
        fontSize = 36.sp,
        lineHeight = 42.sp,
        letterSpacing = (-1.2).sp,
        fontFeatureSettings = "tnum"
    ),
    headlineMedium = TextStyle(
        fontWeight = FontWeight.SemiBold,
        fontSize = 22.sp,
        lineHeight = 28.sp,
        letterSpacing = (-0.4).sp
    ),
    headlineSmall = TextStyle(
        fontWeight = FontWeight.SemiBold,
        fontSize = 18.sp,
        lineHeight = 24.sp,
        letterSpacing = (-0.2).sp
    ),
    titleLarge = TextStyle(
        fontWeight = FontWeight.SemiBold,
        fontSize = 17.sp,
        lineHeight = 22.sp,
        letterSpacing = (-0.2).sp
    ),
    titleMedium = TextStyle(
        fontWeight = FontWeight.Medium,
        fontSize = 15.sp,
        lineHeight = 20.sp
    ),
    bodyLarge = TextStyle(
        fontWeight = FontWeight.Normal,
        fontSize = 15.sp,
        lineHeight = 21.sp
    ),
    bodyMedium = TextStyle(
        fontWeight = FontWeight.Normal,
        fontSize = 13.sp,
        lineHeight = 18.sp
    ),
    labelLarge = TextStyle(
        fontWeight = FontWeight.Medium,
        fontSize = 14.sp,
        lineHeight = 18.sp
    ),
    labelMedium = TextStyle(
        fontWeight = FontWeight.Medium,
        fontSize = 12.sp,
        lineHeight = 16.sp
    ),
    labelSmall = TextStyle(
        fontWeight = FontWeight.Medium,
        fontSize = 11.sp,
        lineHeight = 14.sp
    )
)

@Composable
fun StudyFlowTheme(
    content: @Composable () -> Unit
) {
    LightSystemBarsEffect()
    MaterialTheme(
        colorScheme = StudyFlowLinearColorScheme,
        typography = StudyFlowTypography,
        content = content
    )
}
