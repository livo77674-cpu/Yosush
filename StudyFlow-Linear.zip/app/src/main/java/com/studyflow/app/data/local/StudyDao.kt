// ПУТЬ: com/studyflow/app/data/local/StudyDao.kt

package com.studyflow.app.data.local

import androidx.room.ColumnInfo
import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.studyflow.app.domain.model.BlockStatus
import kotlinx.coroutines.flow.Flow

/**
 * Проекция результата агрегации фактически отработанных минут по когнитивному эшелону.
 */
data class TierMinutesSummary(
    @ColumnInfo(name = "tier")
    val tier: Int,

    @ColumnInfo(name = "total_minutes")
    val totalMinutes: Int
)

/**
 * DAO для реактивного и разового доступа к локальной базе данных StudyFlow.
 */
@Dao
interface StudyDao {

    // ------------------------- DailyStateEntity -------------------------

    /**
     * Реактивно наблюдает за состоянием указанного дня (`YYYY-MM-DD`).
     */
    @Query("SELECT * FROM daily_states WHERE date = :date LIMIT 1")
    fun observeDailyState(date: String): Flow<DailyStateEntity?>

    /**
     * Разовое получение состояния на указанную дату.
     */
    @Query("SELECT * FROM daily_states WHERE date = :date LIMIT 1")
    suspend fun getDailyState(date: String): DailyStateEntity?

    /**
     * Вставляет новое состояние дня или полностью заменяет существующее по PrimaryKey `date`.
     */
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertDailyState(state: DailyStateEntity)

    /**
     * Обновляет существующую запись дневного состояния.
     */
    @Update
    suspend fun updateDailyState(state: DailyStateEntity)

    // ------------------------- StudyBlockEntity -------------------------

    /**
     * Реактивно возвращает список всех учебных блоков на указанную дату в порядке добавления.
     */
    @Query("SELECT * FROM study_blocks WHERE date = :date ORDER BY id ASC")
    fun observeBlocksForDate(date: String): Flow<List<StudyBlockEntity>>

    /**
     * Разовая выборка списка учебных блоков на дату (для расчётов в RuleEngine).
     */
    @Query("SELECT * FROM study_blocks WHERE date = :date ORDER BY id ASC")
    suspend fun getBlocksForDate(date: String): List<StudyBlockEntity>

    /**
     * Получает конкретный учебный блок по его идентификатору.
     */
    @Query("SELECT * FROM study_blocks WHERE id = :blockId LIMIT 1")
    suspend fun getBlockById(blockId: Long): StudyBlockEntity?

    /**
     * Вставляет новый учебный блок и возвращает сгенерированный `id`.
     */
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertBlock(block: StudyBlockEntity): Long

    /**
     * Обновляет все поля существующего учебного блока.
     */
    @Update
    suspend fun updateBlock(block: StudyBlockEntity)

    /**
     * Удаляет учебный блок.
     */
    @Delete
    suspend fun deleteBlock(block: StudyBlockEntity)

    /**
     * Атомарно увеличивает счётчик отвлечений («Мысли блуждают») на 1.
     */
    @Query("UPDATE study_blocks SET distraction_count = distraction_count + 1 WHERE id = :blockId")
    suspend fun incrementDistractionCount(blockId: Long)

    /**
     * Сохраняет фактически отработанные минуты по завершении рабочей фазы.
     */
    @Query("UPDATE study_blocks SET actual_minutes = :actualMinutes WHERE id = :blockId")
    suspend fun updateActualMinutes(blockId: Long, actualMinutes: Int)

    /**
     * Сохраняет заметку из 3-минутного буфера закрытия (фаза CLOSURE).
     */
    @Query("UPDATE study_blocks SET closure_note = :closureNote WHERE id = :blockId")
    suspend fun updateClosureNote(blockId: Long, closureNote: String)

    /**
     * Фиксирует итоговую оценку энергии и статус блока после фазы POST_CHECKIN.
     */
    @Query(
        """
        UPDATE study_blocks
        SET energy_after = :energyAfter, status = :status
        WHERE id = :blockId
        """
    )
    suspend fun completePostCheckIn(
        blockId: Long,
        energyAfter: Int,
        status: BlockStatus = BlockStatus.COMPLETED
    )

    /**
     * Понижает эшелон запланированного блока и помечает его как DOWNGRADED.
     */
    @Query(
        """
        UPDATE study_blocks
        SET tier = :newTier, status = :status
        WHERE id = :blockId
        """
    )
    suspend fun downgradeBlockTier(
        blockId: Long,
        newTier: Int,
        status: BlockStatus = BlockStatus.DOWNGRADED
    )

    // ------------------------- Агрегация по Tier -------------------------

    /**
     * Реактивно подсчитывает сумму `actual_minutes` по каждому эшелону (`tier`) за день.
     */
    @Query(
        """
        SELECT tier, COALESCE(SUM(actual_minutes), 0) AS total_minutes
        FROM study_blocks
        WHERE date = :date
        GROUP BY tier
        ORDER BY tier ASC
        """
    )
    fun observeActualMinutesByTier(date: String): Flow<List<TierMinutesSummary>>

    /**
     * Разовый подсчёт суммы `actual_minutes` по каждому эшелону за день.
     */
    @Query(
        """
        SELECT tier, COALESCE(SUM(actual_minutes), 0) AS total_minutes
        FROM study_blocks
        WHERE date = :date
        GROUP BY tier
        ORDER BY tier ASC
        """
    )
    suspend fun getActualMinutesByTier(date: String): List<TierMinutesSummary>

    /**
     * Реактивно возвращает сумму `actual_minutes` для конкретного эшелона (например, TIER_1) за день.
     */
    @Query(
        """
        SELECT COALESCE(SUM(actual_minutes), 0)
        FROM study_blocks
        WHERE date = :date AND tier = :tier
        """
    )
    fun observeActualMinutesForTier(date: String, tier: Int): Flow<Int>

    /**
     * Разово возвращает сумму `actual_minutes` для конкретного эшелона за день.
     */
    @Query(
        """
        SELECT COALESCE(SUM(actual_minutes), 0)
        FROM study_blocks
        WHERE date = :date AND tier = :tier
        """
    )
    suspend fun getActualMinutesForTier(date: String, tier: Int): Int
}
