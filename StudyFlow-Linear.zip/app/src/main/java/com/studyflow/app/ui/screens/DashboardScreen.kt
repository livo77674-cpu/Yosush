// ПУТЬ: com/studyflow/app/ui/screens/DashboardScreen.kt

package com.studyflow.app.ui.screens

import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.spring
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.Check
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Snackbar
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.studyflow.app.data.local.DailyStateEntity
import com.studyflow.app.data.local.StudyBlockEntity
import com.studyflow.app.domain.engine.EnergyAdaptationAction
import com.studyflow.app.domain.engine.RuleEngine
import com.studyflow.app.domain.model.BlockStatus
import com.studyflow.app.domain.model.CognitiveTier
import com.studyflow.app.ui.theme.LightSystemBarsEffect
import com.studyflow.app.ui.theme.LiquidGlassSurface
import com.studyflow.app.ui.theme.MetallicSurface
import com.studyflow.app.ui.theme.StudyFlowColors
import com.studyflow.app.ui.theme.accentColor
import com.studyflow.app.ui.theme.cleanLabel
import com.studyflow.app.ui.theme.metallicCanvasBackground
import com.studyflow.app.ui.viewmodel.StudyUiState
import java.time.LocalDate
import java.time.format.DateTimeFormatter
import java.util.Locale
import kotlin.math.roundToInt

private enum class DashboardSegment(val label: String) {
    TIMER("Таймер"),
    SUMMARY("Сводка")
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DashboardScreen(
    uiState: StudyUiState,
    onSaveMorningSleep: (Int) -> Unit,
    onAddBlock: (title: String, tier: CognitiveTier, plannedMinutes: Int) -> Unit,
    onDeleteBlock: (StudyBlockEntity) -> Unit,
    onStartBlock: (block: StudyBlockEntity, energyBefore: Int) -> Unit,
    onApplyEnergyAdaptation: (List<StudyBlockEntity>) -> Unit,
    onDismissSnackbar: () -> Unit
) {
    LightSystemBarsEffect()

    val haptics = LocalHapticFeedback.current
    val snackbarHostState = remember { SnackbarHostState() }

    var selectedTabIndex by rememberSaveable { mutableIntStateOf(0) }
    var showSleepSheet by rememberSaveable { mutableStateOf(false) }
    var showAddSheet by rememberSaveable { mutableStateOf(false) }
    var blockPendingStart by remember { mutableStateOf<StudyBlockEntity?>(null) }

    val activeTab = DashboardSegment.entries[selectedTabIndex.coerceIn(0, 1)]

    LaunchedEffect(uiState.snackbarMessage) {
        val raw = uiState.snackbarMessage
        if (!raw.isNullOrBlank()) {
            snackbarHostState.showSnackbar(sanitizeSystemText(raw))
            onDismissSnackbar()
        }
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .metallicCanvasBackground()
    ) {
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .statusBarsPadding(),
            contentPadding = PaddingValues(
                start = 20.dp,
                end = 20.dp,
                top = 12.dp,
                bottom = if (activeTab == DashboardSegment.TIMER) 128.dp else 44.dp
            ),
            verticalArrangement = Arrangement.spacedBy(20.dp)
        ) {
            // 1. Верхняя панель: дата + пилюля серии слева, Liquid Glass капсула сна справа
            item(key = "top_bar") {
                DashboardTopBar(
                    dateIso = uiState.todayDate,
                    dailyState = uiState.dailyState,
                    onSleepClick = {
                        haptics.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                        showSleepSheet = true
                    }
                )
            }

            // 2. Центральный фокус: общий таймер дня + компактная металлическая капсула ресурса
            item(key = "hero_focus") {
                HeroDailyFocus(
                    totalMinutesToday = uiState.totalMinutesToday,
                    hardUsedMinutes = uiState.tier1Overload.usedMinutes,
                    hardLimitMinutes = uiState.tier1Overload.limitMinutes
                )
            }

            // 3. Liquid Glass переключатель вкладок (Таймер / Сводка)
            item(key = "segmented_control") {
                LiquidGlassSegmentedControl(
                    selected = activeTab,
                    onSelect = { segment ->
                        if (segment != activeTab) {
                            haptics.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                            selectedTabIndex = segment.ordinal
                        }
                    }
                )
            }

            // 4. Контент выбранной вкладки
            when (activeTab) {
                DashboardSegment.TIMER -> {
                    val insight = resolveRuleInsight(uiState)
                    val hasPlanned = uiState.blocks.any { it.status == BlockStatus.PLANNED }

                    if (insight != null) {
                        item(key = "rule_insight") {
                            RuleInsightBanner(
                                text = insight.message,
                                accentColor = insight.accent,
                                showAction = hasPlanned,
                                onActionClick = {
                                    haptics.performHapticFeedback(HapticFeedbackType.LongPress)
                                    onApplyEnergyAdaptation(uiState.blocks)
                                }
                            )
                        }
                    }

                    item(key = "linear_task_sheet") {
                        LinearTaskSheet(
                            blocks = uiState.blocks,
                            onStartRowClick = { block ->
                                haptics.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                                blockPendingStart = block
                            },
                            onDeleteClick = { block ->
                                haptics.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                                onDeleteBlock(block)
                            }
                        )
                    }
                }

                DashboardSegment.SUMMARY -> {
                    item(key = "bento_summary") {
                        MetallicBentoSummary(uiState = uiState)
                    }
                }
            }
        }

        // Плавающий нижний Liquid Glass док с кнопкой «+ Добавить» на вкладке Таймер
        if (activeTab == DashboardSegment.TIMER) {
            Box(
                modifier = Modifier
                    .align(Alignment.BottomCenter)
                    .fillMaxWidth()
                    .navigationBarsPadding()
                    .padding(horizontal = 20.dp, vertical = 14.dp)
            ) {
                LiquidGlassSurface(
                    shape = RoundedCornerShape(20.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Box(modifier = Modifier.padding(8.dp)) {
                        Button(
                            onClick = {
                                haptics.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                                showAddSheet = true
                            },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(48.dp),
                            shape = RoundedCornerShape(14.dp),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = StudyFlowColors.InkGraphite,
                                contentColor = Color.White
                            ),
                            elevation = ButtonDefaults.buttonElevation(
                                defaultElevation = 0.dp,
                                pressedElevation = 0.dp
                            )
                        ) {
                            Icon(
                                imageVector = Icons.Rounded.Add,
                                contentDescription = null,
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "Добавить",
                                style = MaterialTheme.typography.labelLarge,
                                fontWeight = FontWeight.Medium
                            )
                        }
                    }
                }
            }
        }

        // Snackbar поверх контента
        SnackbarHost(
            hostState = snackbarHostState,
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .navigationBarsPadding()
                .padding(horizontal = 20.dp, vertical = 84.dp)
        ) { data ->
            Snackbar(
                snackbarData = data,
                containerColor = StudyFlowColors.InkGraphite,
                contentColor = Color.White,
                shape = RoundedCornerShape(14.dp)
            )
        }
    }

    // Bottom Sheet: оценка сна (1–5)
    if (showSleepSheet) {
        SleepCheckInBottomSheet(
            initialSleep = uiState.dailyState?.sleepQuality ?: 4,
            onDismiss = { showSleepSheet = false },
            onSave = { score ->
                showSleepSheet = false
                onSaveMorningSleep(score)
            }
        )
    }

    // Bottom Sheet: однотаповый выбор энергии перед стартом блока (1–5)
    blockPendingStart?.let { targetBlock ->
        PreStartEnergyBottomSheet(
            block = targetBlock,
            onDismiss = { blockPendingStart = null },
            onSelectAndStart = { level ->
                blockPendingStart = null
                onStartBlock(targetBlock, level)
            }
        )
    }

    // Bottom Sheet: добавление нового предмета
    if (showAddSheet) {
        AddSubjectBottomSheet(
            isHardCapacityExhausted = uiState.tier1Overload.isTier1Blocked ||
                uiState.deloadEvaluation.isDeloadRecommended,
            onDismiss = { showAddSheet = false },
            onCreate = { title, tier, minutes ->
                showAddSheet = false
                onAddBlock(title, tier, minutes)
            }
        )
    }
}

@Composable
private fun DashboardTopBar(
    dateIso: String,
    dailyState: DailyStateEntity?,
    onSleepClick: () -> Unit
) {
    val formattedDate = remember(dateIso) { formatRussianDate(dateIso) }
    val streakDays = dailyState?.consecutiveWorkDays?.coerceAtLeast(1) ?: 1

    Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Text(
                text = formattedDate,
                style = MaterialTheme.typography.titleMedium,
                color = StudyFlowColors.InkGraphite
            )

            MetallicSurface(shape = RoundedCornerShape(999.dp)) {
                Text(
                    text = "День $streakDays",
                    style = MaterialTheme.typography.labelSmall.copy(fontFeatureSettings = "tnum"),
                    color = StudyFlowColors.SlateSecondary,
                    modifier = Modifier.padding(horizontal = 9.dp, vertical = 4.dp)
                )
            }
        }

        // Интерактивная Liquid Glass капсула сна
        LiquidGlassSurface(
            shape = RoundedCornerShape(999.dp),
            modifier = Modifier.clickable(onClick = onSleepClick)
        ) {
            Row(
                modifier = Modifier.padding(horizontal = 12.dp, vertical = 7.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(7.dp)
            ) {
                val dotColor = when {
                    dailyState == null -> StudyFlowColors.LoadPracticeAccent
                    dailyState.sleepQuality <= RuleEngine.POOR_SLEEP_THRESHOLD -> StudyFlowColors.LoadPracticeAccent
                    else -> StudyFlowColors.LoadLightAccent
                }
                Box(
                    modifier = Modifier
                        .size(6.dp)
                        .clip(CircleShape)
                        .background(dotColor)
                )
                Text(
                    text = if (dailyState != null) {
                        "Сон ${dailyState.sleepQuality}/5"
                    } else {
                        "Оценить сон"
                    },
                    style = MaterialTheme.typography.labelMedium.copy(fontFeatureSettings = "tnum"),
                    color = StudyFlowColors.InkGraphite
                )
            }
        }
    }
}

@Composable
private fun HeroDailyFocus(
    totalMinutesToday: Int,
    hardUsedMinutes: Int,
    hardLimitMinutes: Int
) {
    val totalFormatted = remember(totalMinutesToday) { formatMinutesAsHms(totalMinutesToday) }
    val progress = when {
        hardLimitMinutes <= 0 -> 1f
        else -> (hardUsedMinutes.toFloat() / hardLimitMinutes.toFloat()).coerceIn(0f, 1f)
    }

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(top = 8.dp, bottom = 4.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Text(
            text = totalFormatted,
            style = MaterialTheme.typography.displayLarge.copy(
                fontSize = 54.sp,
                lineHeight = 60.sp,
                fontWeight = FontWeight.Medium,
                letterSpacing = (-2.0).sp,
                fontFeatureSettings = "tnum"
            ),
            color = StudyFlowColors.InkGraphite,
            maxLines = 1
        )

        // Компактная металлическая капсула ресурса высокой нагрузки
        MetallicSurface(shape = RoundedCornerShape(999.dp)) {
            Column(
                modifier = Modifier
                    .padding(horizontal = 16.dp, vertical = 9.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(7.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(6.dp)
                            .clip(CircleShape)
                            .background(StudyFlowColors.LoadHardAccent)
                    )
                    Text(
                        text = "Сложное · $hardUsedMinutes / $hardLimitMinutes мин",
                        style = MaterialTheme.typography.labelMedium.copy(
                            fontFeatureSettings = "tnum"
                        ),
                        color = StudyFlowColors.SlateSecondary
                    )
                }

                // Тонкая 3.dp шкала прогресса
                Box(
                    modifier = Modifier
                        .width(172.dp)
                        .height(3.dp)
                        .clip(RoundedCornerShape(999.dp))
                        .background(StudyFlowColors.ProgressTrack)
                ) {
                    Box(
                        modifier = Modifier
                            .fillMaxHeight()
                            .fillMaxWidth(progress)
                            .clip(RoundedCornerShape(999.dp))
                            .background(StudyFlowColors.InkGraphite)
                    )
                }
            }
        }
    }
}

@Composable
private fun LiquidGlassSegmentedControl(
    selected: DashboardSegment,
    onSelect: (DashboardSegment) -> Unit
) {
    val trackPadding = 3.dp
    BoxWithConstraints(
        modifier = Modifier
            .fillMaxWidth()
            .height(40.dp)
            .clip(RoundedCornerShape(999.dp))
            .background(StudyFlowColors.SegmentedTrack.copy(alpha = 0.70f))
            .border(
                width = 0.5.dp,
                color = StudyFlowColors.MetalBorderBottom.copy(alpha = 0.7f),
                shape = RoundedCornerShape(999.dp)
            )
            .padding(trackPadding)
    ) {
        val segmentWidth = maxWidth / 2
        val targetOffset = if (selected == DashboardSegment.TIMER) 0.dp else segmentWidth
        val pillOffset by animateDpAsState(
            targetValue = targetOffset,
            animationSpec = spring(
                dampingRatio = Spring.DampingRatioNoBouncy,
                stiffness = Spring.StiffnessMediumLow
            ),
            label = "segmented_pill_offset"
        )

        // Скользящая Liquid Glass пилюля активной вкладки
        LiquidGlassSurface(
            shape = RoundedCornerShape(999.dp),
            modifier = Modifier
                .offset(x = pillOffset)
                .width(segmentWidth)
                .fillMaxHeight()
        ) {}

        Row(modifier = Modifier.fillMaxSize()) {
            DashboardSegment.entries.forEach { segment ->
                val isSelected = segment == selected
                val interactionSource = remember { MutableInteractionSource() }
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxHeight()
                        .clip(RoundedCornerShape(999.dp))
                        .clickable(
                            interactionSource = interactionSource,
                            indication = null,
                            onClick = { onSelect(segment) }
                        ),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = segment.label,
                        style = MaterialTheme.typography.labelLarge,
                        fontWeight = if (isSelected) FontWeight.SemiBold else FontWeight.Medium,
                        color = if (isSelected) {
                            StudyFlowColors.InkGraphite
                        } else {
                            StudyFlowColors.SlateSecondary
                        }
                    )
                }
            }
        }
    }
}

private data class RuleInsight(
    val message: String,
    val accent: Color
)

private fun resolveRuleInsight(uiState: StudyUiState): RuleInsight? = when {
    uiState.energyDropEvaluation.action == EnergyAdaptationAction.SHORTEN_DAY_OR_STOP ->
        RuleInsight(
            message = "Силы снизились · стоит облегчить план",
            accent = StudyFlowColors.LoadPracticeAccent
        )

    uiState.energyDropEvaluation.action == EnergyAdaptationAction.DOWNGRADE_NEXT_TASKS ->
        RuleInsight(
            message = "Спад энергии 2 блока подряд",
            accent = StudyFlowColors.LoadPracticeAccent
        )

    uiState.deloadEvaluation.isDeloadRecommended ->
        RuleInsight(
            message = "День ${uiState.deloadEvaluation.consecutiveWorkDays} подряд · без сложных задач",
            accent = StudyFlowColors.LoadHardAccent
        )

    uiState.tier1Overload.isTier1Blocked ->
        RuleInsight(
            message = "Лимит сложного исчерпан · практика и лёгкое",
            accent = StudyFlowColors.LoadHardAccent
        )

    else -> null
}

@Composable
private fun RuleInsightBanner(
    text: String,
    accentColor: Color,
    showAction: Boolean,
    onActionClick: () -> Unit
) {
    MetallicSurface(
        shape = RoundedCornerShape(16.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 14.dp, vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .width(2.dp)
                    .height(22.dp)
                    .clip(RoundedCornerShape(999.dp))
                    .background(accentColor)
            )
            Spacer(modifier = Modifier.width(12.dp))
            Text(
                text = text,
                style = MaterialTheme.typography.bodyMedium,
                color = StudyFlowColors.InkGraphite,
                modifier = Modifier.weight(1f)
            )
            if (showAction) {
                Spacer(modifier = Modifier.width(8.dp))
                TextButton(
                    onClick = onActionClick,
                    contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp)
                ) {
                    Text(
                        text = "Облегчить",
                        style = MaterialTheme.typography.labelLarge,
                        color = StudyFlowColors.InkGraphite
                    )
                }
            }
        }
    }
}

@Composable
private fun LinearTaskSheet(
    blocks: List<StudyBlockEntity>,
    onStartRowClick: (StudyBlockEntity) -> Unit,
    onDeleteClick: (StudyBlockEntity) -> Unit
) {
    MetallicSurface(
        shape = RoundedCornerShape(20.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        if (blocks.isEmpty()) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 24.dp, vertical = 40.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                Text(
                    text = "План на сегодня пуст",
                    style = MaterialTheme.typography.titleMedium,
                    color = StudyFlowColors.InkGraphite
                )
                Text(
                    text = "Нажмите «Добавить» ниже",
                    style = MaterialTheme.typography.bodyMedium,
                    color = StudyFlowColors.SlateSecondary
                )
            }
        } else {
            Column(modifier = Modifier.fillMaxWidth()) {
                blocks.forEachIndexed { index, block ->
                    LinearTaskRow(
                        block = block,
                        onRowClick = {
                            if (block.status != BlockStatus.COMPLETED) {
                                onStartRowClick(block)
                            }
                        },
                        onDeleteClick = { onDeleteClick(block) }
                    )
                    if (index < blocks.lastIndex) {
                        HorizontalDivider(
                            modifier = Modifier.padding(start = 66.dp, end = 16.dp),
                            thickness = 0.5.dp,
                            color = StudyFlowColors.SheetRowDivider
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun LinearTaskRow(
    block: StudyBlockEntity,
    onRowClick: () -> Unit,
    onDeleteClick: () -> Unit
) {
    val tier = block.toCognitiveTier()
    val isCompleted = block.status == BlockStatus.COMPLETED

    val durationText = if (isCompleted) {
        formatCompletedMinutes(block.actualMinutes.coerceAtLeast(1))
    } else {
        "${block.plannedMinutes} мин"
    }

    val subtitleText = if (block.status == BlockStatus.DOWNGRADED) {
        "${tier.cleanLabel()} · облегчено"
    } else {
        tier.cleanLabel()
    }

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(enabled = !isCompleted, onClick = onRowClick)
            .padding(start = 16.dp, end = 10.dp, top = 13.dp, bottom = 13.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        // Тактильная круглая металлическая кнопка Play (36.dp) с 6.dp точкой сложности
        Box(modifier = Modifier.size(38.dp)) {
            Box(
                modifier = Modifier
                    .size(36.dp)
                    .align(Alignment.Center)
                    .clip(CircleShape)
                    .background(
                        Brush.verticalGradient(
                            colors = listOf(Color.White, Color(0xFFF1F4F8))
                        )
                    )
                    .border(
                        width = 1.dp,
                        color = StudyFlowColors.PlayRingBorder,
                        shape = CircleShape
                    ),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = if (isCompleted) Icons.Rounded.Check else Icons.Rounded.PlayArrow,
                    contentDescription = if (isCompleted) "Готово" else "Старт",
                    tint = if (isCompleted) {
                        StudyFlowColors.SlateSecondary
                    } else {
                        StudyFlowColors.InkGraphite
                    },
                    modifier = Modifier.size(17.dp)
                )
            }

            // 6.dp точка сложности на ободке кнопки
            Box(
                modifier = Modifier
                    .size(8.dp)
                    .align(Alignment.BottomEnd)
                    .clip(CircleShape)
                    .background(Color.White)
                    .padding(1.dp)
                    .clip(CircleShape)
                    .background(
                        if (isCompleted) tier.accentColor().copy(alpha = 0.45f) else tier.accentColor()
                    )
            )
        }

        Spacer(modifier = Modifier.width(12.dp))

        // Название и лаконичная подпись сложности
        Column(
            modifier = Modifier.weight(1f),
            verticalArrangement = Arrangement.spacedBy(2.dp)
        ) {
            Text(
                text = block.title,
                style = MaterialTheme.typography.titleMedium.copy(
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Medium
                ),
                color = if (isCompleted) StudyFlowColors.SlateSecondary else StudyFlowColors.InkGraphite,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            Text(
                text = subtitleText,
                style = MaterialTheme.typography.labelMedium.copy(fontSize = 12.sp),
                color = StudyFlowColors.SlateSecondary
            )
        }

        Spacer(modifier = Modifier.width(10.dp))

        // Моноширинная длительность
        Text(
            text = durationText,
            style = MaterialTheme.typography.bodyMedium.copy(
                fontWeight = FontWeight.Medium,
                fontFeatureSettings = "tnum"
            ),
            color = if (isCompleted) StudyFlowColors.SlateSecondary else StudyFlowColors.InkGraphite
        )

        IconButton(
            onClick = onDeleteClick,
            modifier = Modifier.size(34.dp)
        ) {
            Icon(
                imageVector = Icons.Rounded.Delete,
                contentDescription = "Удалить",
                tint = StudyFlowColors.SilverMuted,
                modifier = Modifier.size(17.dp)
            )
        }
    }
}

@Composable
private fun MetallicBentoSummary(
    uiState: StudyUiState
) {
    val hardMin = uiState.minutesForTier(CognitiveTier.TIER_1)
    val practiceMin = uiState.minutesForTier(CognitiveTier.TIER_2)
    val lightMin = uiState.minutesForTier(CognitiveTier.TIER_3)
    val hardLimit = uiState.tier1Overload.limitMinutes
    val completedCount = uiState.blocks.count { it.status == BlockStatus.COMPLETED }
    val energySamples = remember(uiState.blocks) {
        uiState.blocks.mapNotNull { it.energyAfter }
    }
    val checkpoints = remember(uiState.blocks) {
        uiState.blocks.filter { it.closureNote.isNotBlank() }
    }

    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        // Асимметричная верхняя строка Bento
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            MetallicSurface(
                shape = RoundedCornerShape(22.dp),
                modifier = Modifier.weight(1.25f)
            ) {
                Column(
                    modifier = Modifier.padding(18.dp),
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Text(
                        text = "Всего за день",
                        style = MaterialTheme.typography.labelMedium,
                        color = StudyFlowColors.SlateSecondary
                    )
                    Text(
                        text = formatMinutesAsHms(uiState.totalMinutesToday),
                        style = MaterialTheme.typography.displayMedium.copy(
                            fontSize = 30.sp,
                            lineHeight = 36.sp,
                            fontFeatureSettings = "tnum"
                        ),
                        color = StudyFlowColors.InkGraphite,
                        maxLines = 1
                    )
                    Text(
                        text = "Блоков · $completedCount / ${uiState.blocks.size}",
                        style = MaterialTheme.typography.labelSmall.copy(fontFeatureSettings = "tnum"),
                        color = StudyFlowColors.SilverMuted
                    )
                }
            }

            MetallicSurface(
                shape = RoundedCornerShape(22.dp),
                modifier = Modifier.weight(1f)
            ) {
                Column(
                    modifier = Modifier.padding(18.dp),
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Text(
                        text = "Запас сложного",
                        style = MaterialTheme.typography.labelMedium,
                        color = StudyFlowColors.SlateSecondary
                    )
                    Text(
                        text = "${uiState.tier1Overload.remainingMinutes}",
                        style = MaterialTheme.typography.displayMedium.copy(
                            fontSize = 30.sp,
                            lineHeight = 36.sp,
                            fontFeatureSettings = "tnum"
                        ),
                        color = StudyFlowColors.InkGraphite
                    )
                    Text(
                        text = "из $hardLimit мин",
                        style = MaterialTheme.typography.labelSmall.copy(fontFeatureSettings = "tnum"),
                        color = StudyFlowColors.SilverMuted
                    )
                }
            }
        }

        // Разбивка по нагрузке: Сложное / Практика / Лёгкое с 4.dp шкалами
        MetallicSurface(
            shape = RoundedCornerShape(22.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(
                modifier = Modifier.padding(18.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                Text(
                    text = "Нагрузка",
                    style = MaterialTheme.typography.titleMedium,
                    color = StudyFlowColors.InkGraphite
                )

                val referenceMax = maxOf(hardLimit, hardMin, practiceMin, lightMin, 60).toFloat()

                BentoLoadRow(
                    label = CognitiveTier.TIER_1.cleanLabel(),
                    valueText = "$hardMin / $hardLimit мин",
                    progress = if (hardLimit > 0) {
                        (hardMin / hardLimit.toFloat()).coerceIn(0f, 1f)
                    } else {
                        1f
                    },
                    accent = CognitiveTier.TIER_1.accentColor()
                )
                BentoLoadRow(
                    label = CognitiveTier.TIER_2.cleanLabel(),
                    valueText = "$practiceMin мин",
                    progress = (practiceMin / referenceMax).coerceIn(0f, 1f),
                    accent = CognitiveTier.TIER_2.accentColor()
                )
                BentoLoadRow(
                    label = CognitiveTier.TIER_3.cleanLabel(),
                    valueText = "$lightMin мин",
                    progress = (lightMin / referenceMax).coerceIn(0f, 1f),
                    accent = CognitiveTier.TIER_3.accentColor()
                )
            }
        }

        // Минималистичный график тренда энергии на Canvas
        MetallicSurface(
            shape = RoundedCornerShape(22.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(
                modifier = Modifier.padding(18.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Динамика сил",
                        style = MaterialTheme.typography.titleMedium,
                        color = StudyFlowColors.InkGraphite
                    )
                    Text(
                        text = energySamples.lastOrNull()?.let { "$it / 5" } ?: "—",
                        style = MaterialTheme.typography.labelMedium.copy(fontFeatureSettings = "tnum"),
                        color = StudyFlowColors.SlateSecondary
                    )
                }

                if (energySamples.isEmpty()) {
                    Text(
                        text = "Появится после первого завершённого блока",
                        style = MaterialTheme.typography.bodyMedium,
                        color = StudyFlowColors.SilverMuted
                    )
                } else {
                    EnergyTrendCanvas(
                        samples = energySamples,
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(84.dp)
                    )
                }
            }
        }

        // Точки остановки на завтра
        MetallicSurface(
            shape = RoundedCornerShape(22.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(
                modifier = Modifier.padding(18.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Text(
                    text = "Точки остановки на завтра",
                    style = MaterialTheme.typography.titleMedium,
                    color = StudyFlowColors.InkGraphite
                )

                if (checkpoints.isEmpty()) {
                    Text(
                        text = "Заметок пока нет",
                        style = MaterialTheme.typography.bodyMedium,
                        color = StudyFlowColors.SilverMuted
                    )
                } else {
                    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        checkpoints.forEachIndexed { index, block ->
                            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(7.dp)
                                ) {
                                    Box(
                                        modifier = Modifier
                                            .size(6.dp)
                                            .clip(CircleShape)
                                            .background(block.toCognitiveTier().accentColor())
                                    )
                                    Text(
                                        text = block.title,
                                        style = MaterialTheme.typography.labelLarge,
                                        color = StudyFlowColors.InkGraphite,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                }
                                Text(
                                    text = block.closureNote,
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = StudyFlowColors.SlateSecondary,
                                    modifier = Modifier.padding(start = 13.dp)
                                )
                            }
                            if (index < checkpoints.lastIndex) {
                                HorizontalDivider(
                                    thickness = 0.5.dp,
                                    color = StudyFlowColors.HairlineDivider
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun BentoLoadRow(
    label: String,
    valueText: String,
    progress: Float,
    accent: Color
) {
    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(7.dp)
            ) {
                Box(
                    modifier = Modifier
                        .size(6.dp)
                        .clip(CircleShape)
                        .background(accent)
                )
                Text(
                    text = label,
                    style = MaterialTheme.typography.bodyMedium,
                    color = StudyFlowColors.InkGraphite
                )
            }
            Text(
                text = valueText,
                style = MaterialTheme.typography.labelMedium.copy(fontFeatureSettings = "tnum"),
                color = StudyFlowColors.SlateSecondary
            )
        }

        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(4.dp)
                .clip(RoundedCornerShape(999.dp))
                .background(StudyFlowColors.ProgressTrack)
        ) {
            Box(
                modifier = Modifier
                    .fillMaxHeight()
                    .fillMaxWidth(progress)
                    .clip(RoundedCornerShape(999.dp))
                    .background(accent)
            )
        }
    }
}

@Composable
private fun EnergyTrendCanvas(
    samples: List<Int>,
    modifier: Modifier = Modifier
) {
    Canvas(modifier = modifier) {
        val horizontalPad = 8.dp.toPx()
        val verticalPad = 10.dp.toPx()
        val chartWidth = (size.width - horizontalPad * 2).coerceAtLeast(1f)
        val chartHeight = (size.height - verticalPad * 2).coerceAtLeast(1f)

        // Тонкие горизонтальные направляющие (уровни 1, 3, 5)
        listOf(0f, 0.5f, 1f).forEach { fraction ->
            val y = verticalPad + chartHeight * fraction
            drawLine(
                color = StudyFlowColors.HairlineDivider,
                start = Offset(horizontalPad, y),
                end = Offset(size.width - horizontalPad, y),
                strokeWidth = 0.75.dp.toPx()
            )
        }

        val points = samples.mapIndexed { index, rawLevel ->
            val clamped = rawLevel.coerceIn(1, 5)
            val x = if (samples.size == 1) {
                horizontalPad + chartWidth * 0.5f
            } else {
                horizontalPad + chartWidth * (index.toFloat() / (samples.size - 1).toFloat())
            }
            val normalizedY = (5 - clamped) / 4f
            val y = verticalPad + chartHeight * normalizedY
            Offset(x, y)
        }

        if (points.size >= 2) {
            val linePath = Path().apply {
                moveTo(points.first().x, points.first().y)
                for (i in 1 until points.size) {
                    val prev = points[i - 1]
                    val curr = points[i]
                    val midX = (prev.x + curr.x) / 2f
                    cubicTo(midX, prev.y, midX, curr.y, curr.x, curr.y)
                }
            }

            val areaPath = Path().apply {
                addPath(linePath)
                lineTo(points.last().x, size.height - verticalPad)
                lineTo(points.first().x, size.height - verticalPad)
                close()
            }

            drawPath(
                path = areaPath,
                brush = Brush.verticalGradient(
                    colors = listOf(
                        StudyFlowColors.InkGraphite.copy(alpha = 0.10f),
                        Color.Transparent
                    ),
                    startY = verticalPad,
                    endY = size.height - verticalPad
                )
            )

            drawPath(
                path = linePath,
                color = StudyFlowColors.InkGraphite,
                style = Stroke(
                    width = 1.75.dp.toPx(),
                    cap = StrokeCap.Round,
                    join = StrokeJoin.Round
                )
            )
        }

        points.forEach { pt ->
            drawCircle(
                color = Color.White,
                radius = 4.5.dp.toPx(),
                center = pt
            )
            drawCircle(
                color = StudyFlowColors.InkGraphite,
                radius = 3.dp.toPx(),
                center = pt
            )
        }
    }
}

@Composable
private fun SheetDragHandle() {
    Box(
        modifier = Modifier
            .padding(top = 10.dp, bottom = 6.dp)
            .width(34.dp)
            .height(4.dp)
            .clip(RoundedCornerShape(999.dp))
            .background(StudyFlowColors.MetalBorderBottom)
    )
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun SleepCheckInBottomSheet(
    initialSleep: Int,
    onDismiss: () -> Unit,
    onSave: (Int) -> Unit
) {
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
    val haptics = LocalHapticFeedback.current
    var selected by rememberSaveable { mutableIntStateOf(initialSleep.coerceIn(1, 5)) }
    val limitPreview = RuleEngine.calculateTier1DailyLimit(sleepQuality = selected)

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = sheetState,
        containerColor = StudyFlowColors.CanvasTop,
        contentColor = StudyFlowColors.InkGraphite,
        scrimColor = StudyFlowColors.InkGraphite.copy(alpha = 0.28f),
        shape = RoundedCornerShape(topStart = 24.dp, topEnd = 24.dp),
        dragHandle = { SheetDragHandle() }
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .navigationBarsPadding()
                .padding(horizontal = 20.dp, vertical = 14.dp),
            verticalArrangement = Arrangement.spacedBy(18.dp)
        ) {
            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text(
                    text = "Качество сна",
                    style = MaterialTheme.typography.headlineSmall,
                    color = StudyFlowColors.InkGraphite
                )
                Text(
                    text = "Сложное · $limitPreview мин на сегодня",
                    style = MaterialTheme.typography.bodyMedium.copy(fontFeatureSettings = "tnum"),
                    color = StudyFlowColors.SlateSecondary
                )
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                (1..5).forEach { score ->
                    val isSelected = selected == score
                    TactileScoreTile(
                        score = score,
                        isSelected = isSelected,
                        modifier = Modifier.weight(1f),
                        onClick = {
                            haptics.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                            selected = score
                        }
                    )
                }
            }

            Button(
                onClick = {
                    haptics.performHapticFeedback(HapticFeedbackType.LongPress)
                    onSave(selected)
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(50.dp),
                shape = RoundedCornerShape(14.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = StudyFlowColors.InkGraphite,
                    contentColor = Color.White
                ),
                elevation = ButtonDefaults.buttonElevation(defaultElevation = 0.dp)
            ) {
                Text(
                    text = "Сохранить",
                    style = MaterialTheme.typography.labelLarge
                )
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun PreStartEnergyBottomSheet(
    block: StudyBlockEntity,
    onDismiss: () -> Unit,
    onSelectAndStart: (Int) -> Unit
) {
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
    val haptics = LocalHapticFeedback.current

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = sheetState,
        containerColor = StudyFlowColors.CanvasTop,
        contentColor = StudyFlowColors.InkGraphite,
        scrimColor = StudyFlowColors.InkGraphite.copy(alpha = 0.28f),
        shape = RoundedCornerShape(topStart = 24.dp, topEnd = 24.dp),
        dragHandle = { SheetDragHandle() }
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .navigationBarsPadding()
                .padding(horizontal = 20.dp, vertical = 14.dp),
            verticalArrangement = Arrangement.spacedBy(18.dp)
        ) {
            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text(
                    text = "Уровень сил перед стартом",
                    style = MaterialTheme.typography.headlineSmall,
                    color = StudyFlowColors.InkGraphite
                )
                Text(
                    text = "${block.title} · ${block.plannedMinutes} мин",
                    style = MaterialTheme.typography.bodyMedium.copy(fontFeatureSettings = "tnum"),
                    color = StudyFlowColors.SlateSecondary,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                (1..5).forEach { level ->
                    TactileScoreTile(
                        score = level,
                        isSelected = false,
                        modifier = Modifier.weight(1f),
                        onClick = {
                            haptics.performHapticFeedback(HapticFeedbackType.LongPress)
                            onSelectAndStart(level)
                        }
                    )
                }
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = "1 · низкий",
                    style = MaterialTheme.typography.labelSmall,
                    color = StudyFlowColors.SilverMuted
                )
                Text(
                    text = "5 · высокий",
                    style = MaterialTheme.typography.labelSmall,
                    color = StudyFlowColors.SilverMuted
                )
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun AddSubjectBottomSheet(
    isHardCapacityExhausted: Boolean,
    onDismiss: () -> Unit,
    onCreate: (title: String, tier: CognitiveTier, plannedMinutes: Int) -> Unit
) {
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
    val haptics = LocalHapticFeedback.current

    var title by rememberSaveable { mutableStateOf("") }
    var selectedTier by remember {
        mutableStateOf(
            if (isHardCapacityExhausted) CognitiveTier.TIER_2 else CognitiveTier.TIER_1
        )
    }
    var durationSlider by rememberSaveable { mutableFloatStateOf(50f) }
    val plannedMinutes = durationSlider.roundToInt().coerceIn(
        RuleEngine.MIN_WORK_DURATION_MINUTES,
        RuleEngine.MAX_WORK_DURATION_MINUTES
    )
    val presets = listOf(50, 65, 80)

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = sheetState,
        containerColor = StudyFlowColors.CanvasTop,
        contentColor = StudyFlowColors.InkGraphite,
        scrimColor = StudyFlowColors.InkGraphite.copy(alpha = 0.28f),
        shape = RoundedCornerShape(topStart = 24.dp, topEnd = 24.dp),
        dragHandle = { SheetDragHandle() }
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .navigationBarsPadding()
                .padding(horizontal = 20.dp, vertical = 14.dp),
            verticalArrangement = Arrangement.spacedBy(18.dp)
        ) {
            Text(
                text = "Новый предмет",
                style = MaterialTheme.typography.headlineSmall,
                color = StudyFlowColors.InkGraphite
            )

            OutlinedTextField(
                value = title,
                onValueChange = { title = it },
                placeholder = {
                    Text(
                        text = "Название",
                        color = StudyFlowColors.SilverMuted
                    )
                },
                singleLine = true,
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(14.dp),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedContainerColor = Color.White,
                    unfocusedContainerColor = Color.White,
                    focusedBorderColor = StudyFlowColors.InkGraphite,
                    unfocusedBorderColor = StudyFlowColors.MetalBorderBottom,
                    cursorColor = StudyFlowColors.InkGraphite,
                    focusedTextColor = StudyFlowColors.InkGraphite,
                    unfocusedTextColor = StudyFlowColors.InkGraphite
                )
            )

            // 3 тактильных чипа сложности (Сложное / Практика / Лёгкое)
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(
                    text = "Сложность",
                    style = MaterialTheme.typography.labelMedium,
                    color = StudyFlowColors.SlateSecondary
                )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    CognitiveTier.entries.forEach { tier ->
                        val isSelected = selectedTier == tier
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .height(42.dp)
                                .clip(RoundedCornerShape(12.dp))
                                .background(
                                    if (isSelected) {
                                        StudyFlowColors.InkGraphite
                                    } else {
                                        Color.White
                                    }
                                )
                                .border(
                                    width = 0.75.dp,
                                    color = if (isSelected) {
                                        StudyFlowColors.InkGraphite
                                    } else {
                                        StudyFlowColors.MetalBorderBottom
                                    },
                                    shape = RoundedCornerShape(12.dp)
                                )
                                .clickable {
                                    haptics.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                                    selectedTier = tier
                                },
                            contentAlignment = Alignment.Center
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(6.dp)
                                        .clip(CircleShape)
                                        .background(
                                            if (isSelected) Color.White else tier.accentColor()
                                        )
                                )
                                Text(
                                    text = tier.cleanLabel(),
                                    style = MaterialTheme.typography.labelLarge,
                                    color = if (isSelected) {
                                        Color.White
                                    } else {
                                        StudyFlowColors.InkGraphite
                                    }
                                )
                            }
                        }
                    }
                }

                if (selectedTier == CognitiveTier.TIER_1 && isHardCapacityExhausted) {
                    Text(
                        text = "Лимит сложного исчерпан · сохранится как «Практика»",
                        style = MaterialTheme.typography.labelSmall,
                        color = StudyFlowColors.LoadPracticeAccent
                    )
                }
            }

            // Выбор длительности: пресеты 50 / 65 / 80 мин + слайдер
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Длительность",
                        style = MaterialTheme.typography.labelMedium,
                        color = StudyFlowColors.SlateSecondary
                    )
                    Text(
                        text = "$plannedMinutes мин",
                        style = MaterialTheme.typography.labelLarge.copy(fontFeatureSettings = "tnum"),
                        color = StudyFlowColors.InkGraphite
                    )
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    presets.forEach { minutes ->
                        val isActive = plannedMinutes == minutes
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .height(36.dp)
                                .clip(RoundedCornerShape(10.dp))
                                .background(
                                    if (isActive) StudyFlowColors.SegmentedTrack else Color.White
                                )
                                .border(
                                    width = 0.75.dp,
                                    color = if (isActive) {
                                        StudyFlowColors.InkGraphite
                                    } else {
                                        StudyFlowColors.MetalBorderBottom
                                    },
                                    shape = RoundedCornerShape(10.dp)
                                )
                                .clickable {
                                    haptics.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                                    durationSlider = minutes.toFloat()
                                },
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = "$minutes мин",
                                style = MaterialTheme.typography.labelMedium.copy(
                                    fontFeatureSettings = "tnum"
                                ),
                                color = StudyFlowColors.InkGraphite
                            )
                        }
                    }
                }

                Slider(
                    value = durationSlider,
                    onValueChange = { durationSlider = it },
                    valueRange = RuleEngine.MIN_WORK_DURATION_MINUTES.toFloat()..
                        RuleEngine.MAX_WORK_DURATION_MINUTES.toFloat(),
                    colors = SliderDefaults.colors(
                        thumbColor = StudyFlowColors.InkGraphite,
                        activeTrackColor = StudyFlowColors.InkGraphite,
                        inactiveTrackColor = StudyFlowColors.ProgressTrack
                    )
                )
            }

            Button(
                onClick = {
                    haptics.performHapticFeedback(HapticFeedbackType.LongPress)
                    onCreate(title, selectedTier, plannedMinutes)
                },
                enabled = title.trim().isNotEmpty(),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(50.dp),
                shape = RoundedCornerShape(14.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = StudyFlowColors.InkGraphite,
                    contentColor = Color.White,
                    disabledContainerColor = StudyFlowColors.ProgressTrack,
                    disabledContentColor = StudyFlowColors.SilverMuted
                ),
                elevation = ButtonDefaults.buttonElevation(defaultElevation = 0.dp)
            ) {
                Text(
                    text = "Создать",
                    style = MaterialTheme.typography.labelLarge
                )
            }
        }
    }
}

@Composable
private fun TactileScoreTile(
    score: Int,
    isSelected: Boolean,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    val bgBrush = if (isSelected) {
        Brush.verticalGradient(
            colors = listOf(StudyFlowColors.InkGraphite, StudyFlowColors.InkGraphite)
        )
    } else {
        Brush.verticalGradient(
            colors = listOf(StudyFlowColors.MetalSurfaceTop, StudyFlowColors.MetalSurfaceBottom)
        )
    }

    Box(
        modifier = modifier
            .height(54.dp)
            .clip(RoundedCornerShape(14.dp))
            .background(brush = bgBrush)
            .border(
                width = 0.75.dp,
                color = if (isSelected) {
                    StudyFlowColors.InkGraphite
                } else {
                    StudyFlowColors.MetalBorderBottom
                },
                shape = RoundedCornerShape(14.dp)
            )
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = score.toString(),
            style = MaterialTheme.typography.titleLarge.copy(fontFeatureSettings = "tnum"),
            color = if (isSelected) Color.White else StudyFlowColors.InkGraphite
        )
    }
}

private fun sanitizeSystemText(raw: String): String {
    return raw
        .replace("TIER_1", "«Сложное»")
        .replace("TIER_2", "«Практика»")
        .replace("TIER_3", "«Лёгкое»")
        .replace("Tier 1", "«Сложное»")
        .replace("Tier 2", "«Практика»")
        .replace("Tier 3", "«Лёгкое»")
}

private fun formatMinutesAsHms(totalMinutes: Int): String {
    val safe = totalMinutes.coerceAtLeast(0)
    val hours = safe / 60
    val minutes = safe % 60
    return String.format(Locale.US, "%d:%02d:00", hours, minutes)
}

private fun formatCompletedMinutes(minutes: Int): String {
    val safe = minutes.coerceAtLeast(0)
    return String.format(Locale.US, "%02d:00", safe)
}

private fun formatRussianDate(dateIso: String): String {
    return runCatching {
        val date = LocalDate.parse(dateIso)
        val formatter = DateTimeFormatter.ofPattern("d MMMM, EEE", Locale.forLanguageTag("ru"))
        date.format(formatter)
    }.getOrDefault(dateIso)
}
