// ПУТЬ: com/studyflow/app/domain/model/Models.kt

package com.studyflow.app.domain.model

/**
 * Когнитивный эшелон (уровень ментальной нагрузки) учебного блока.
 *
 * @property level Числовое представление для хранения в БД Room (1, 2, 3).
 * @property displayName Человекочитаемое название уровня нагрузки.
 * @property methodology Описание типа учебной деятельности.
 * @property baseDailyLimitMinutes Базовый дневной лимит минут (null — без жёсткого потолка).
 */
enum class CognitiveTier(
    val level: Int,
    val displayName: String,
    val methodology: String,
    val baseDailyLimitMinutes: Int?
) {
    TIER_1(
        level = 1,
        displayName = "Тяжёлое (Deliberate Practice)",
        methodology = "Глубокое решение новых задач, сложная теория, целенаправленная практика",
        baseDailyLimitMinutes = 240
    ),
    TIER_2(
        level = 2,
        displayName = "Практика (Active Recall)",
        methodology = "Активное припоминание, карточки, закрепление изученного материала",
        baseDailyLimitMinutes = null
    ),
    TIER_3(
        level = 3,
        displayName = "Лёгкий обзор (Worked Examples)",
        methodology = "Разбор готовых примеров, структурирование заметок, лёгкое повторение",
        baseDailyLimitMinutes = null
    );

    companion object {
        /**
         * Безопасное преобразование числового значения из БД в [CognitiveTier].
         * При некорректном значении возвращает наиболее щадящий [TIER_3].
         */
        fun fromLevel(level: Int): CognitiveTier =
            entries.firstOrNull { it.level == level } ?: TIER_3
    }
}

/**
 * Фазы адаптивного учебного цикла таймера.
 *
 * Последовательность переходов:
 * IDLE -> WORK (50–80 мин) -> CLOSURE (3 мин) -> BREAK (15–20 мин) -> POST_CHECKIN -> IDLE
 */
enum class TimerPhase(
    val displayName: String,
    val minDurationSeconds: Int,
    val maxDurationSeconds: Int
) {
    /** Таймер не активен, ожидание запуска блока. */
    IDLE(
        displayName = "Ожидание",
        minDurationSeconds = 0,
        maxDurationSeconds = 0
    ),

    /** Основная рабочая сессия (50–80 минут). */
    WORK(
        displayName = "Фокусная работа",
        minDurationSeconds = 50 * 60,
        maxDurationSeconds = 80 * 60
    ),

    /**
     * 3-минутный буфер закрытия для снятия остаточного внимания (Attention Residue):
     * фиксация точки остановки и следующего микрошага.
     */
    CLOSURE(
        displayName = "Буфер закрытия",
        minDurationSeconds = 3 * 60,
        maxDurationSeconds = 3 * 60
    ),

    /** Обязательный восстановительный перерыв (15 или 20 минут). */
    BREAK(
        displayName = "Обязательный отдых",
        minDurationSeconds = 15 * 60,
        maxDurationSeconds = 20 * 60
    ),

    /** Пост-оценка субъективной энергии (1–5) для адаптации последующих блоков. */
    POST_CHECKIN(
        displayName = "Оценка энергии",
        minDurationSeconds = 0,
        maxDurationSeconds = 0
    )
}

/**
 * Статус выполнения запланированного учебного блока.
 */
enum class BlockStatus {
    /** Блок запланирован, ещё не завершён. */
    PLANNED,

    /** Блок успешно пройден (включая досрочное завершение через буфер закрытия). */
    COMPLETED,

    /** Блок понижен по когнитивному эшелону или упрощён из-за усталости/перегрузки. */
    DOWNGRADED;

    companion object {
        /**
         * Безопасное восстановление статуса из строкового значения БД.
         */
        fun fromName(value: String): BlockStatus =
            entries.firstOrNull { it.name == value } ?: PLANNED
    }
}
