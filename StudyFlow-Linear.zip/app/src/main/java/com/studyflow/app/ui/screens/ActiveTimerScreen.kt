// ПУТЬ: com/studyflow/app/ui/screens/ActiveTimerScreen.kt

package com.studyflow.app.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.animation.core.EaseInOutSine
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.Text
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.studyflow.app.domain.model.TimerPhase
import com.studyflow.app.service.TimerSnapshot
import com.studyflow.app.ui.theme.LightSystemBarsEffect
import com.studyflow.app.ui.theme.LiquidGlassSurface
import com.studyflow.app.ui.theme.MetallicSurface
import com.studyflow.app.ui.theme.StudyFlowColors
import com.studyflow.app.ui.theme.accentColor
import com.studyflow.app.ui.theme.cleanLabel
import com.studyflow.app.ui.theme.metallicCanvasBackground
import kotlinx.coroutines.delay
import java.util.Locale
import kotlin.math.roundToInt

@Composable
fun ActiveTimerScreen(
    snapshot: TimerSnapshot,
    initialClosureNote: String,
    onPause: () -> Unit,
    onResume: () -> Unit,
    onRegisterDistraction: () -> Unit,
    onTriggerEarlyClosure: () -> Unit,
    onStop: () -> Unit,
    onSaveClosureNote: (blockId: Long, note: String) -> Unit,
    onSubmitPostCheckIn: (blockId: Long, energyAfter: Int) -> Unit
) {
    LightSystemBarsEffect()

    when (snapshot.phase) {
        TimerPhase.WORK -> WorkPhaseScreen(
            snapshot = snapshot,
            onPause = onPause,
            onResume = onResume,
            onRegisterDistraction = onRegisterDistraction,
            onTriggerEarlyClosure = onTriggerEarlyClosure,
            onStop = onStop
        )

        TimerPhase.CLOSURE -> ClosurePhaseScreen(
            snapshot = snapshot,
            initialClosureNote = initialClosureNote,
            onSaveClosureNote = onSaveClosureNote
        )

        TimerPhase.BREAK -> BreakPhaseScreen(
            snapshot = snapshot
        )

        TimerPhase.POST_CHECKIN -> PostCheckInScreen(
            snapshot = snapshot,
            onSubmitPostCheckIn = onSubmitPostCheckIn,
            onFallbackStop = onStop
        )

        TimerPhase.IDLE -> Unit
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun WorkPhaseScreen(
    snapshot: TimerSnapshot,
    onPause: () -> Unit,
    onResume: () -> Unit,
    onRegisterDistraction: () -> Unit,
    onTriggerEarlyClosure: () -> Unit,
    onStop: () -> Unit
) {
    val haptics = LocalHapticFeedback.current
    var showStopSheet by rememberSaveable { mutableStateOf(false) }

    // Спокойное медленное дыхание серебристо-белого ореола за центральной линзой
    val infiniteTransition = rememberInfiniteTransition(label = "breathing_halo")
    val haloScale by infiniteTransition.animateFloat(
        initialValue = 0.88f,
        targetValue = 1.08f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 4400, easing = EaseInOutSine),
            repeatMode = RepeatMode.Reverse
        ),
        label = "halo_scale"
    )
    val haloAlpha by infiniteTransition.animateFloat(
        initialValue = 0.45f,
        targetValue = 0.82f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 4400, easing = EaseInOutSine),
            repeatMode = RepeatMode.Reverse
        ),
        label = "halo_alpha"
    )

    Box(
        modifier = Modifier
            .fillMaxSize()
            .metallicCanvasBackground()
    ) {
        // Дышащее серебристо-белое свечение в центре
        Canvas(modifier = Modifier.fillMaxSize()) {
            val baseRadius = size.minDimension * 0.48f
            val animatedRadius = baseRadius * if (snapshot.isRunning) haloScale else 0.92f
            val alpha = if (snapshot.isRunning) haloAlpha else 0.40f
            drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(
                        Color.White.copy(alpha = alpha),
                        Color(0xFFCBD5E1).copy(alpha = alpha * 0.28f),
                        Color.Transparent
                    ),
                    center = Offset(size.width * 0.5f, size.height * 0.46f),
                    radius = animatedRadius
                ),
                radius = animatedRadius,
                center = Offset(size.width * 0.5f, size.height * 0.46f)
            )
        }

        Column(
            modifier = Modifier
                .fillMaxSize()
                .statusBarsPadding()
                .navigationBarsPadding()
                .padding(horizontal = 20.dp, vertical = 16.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            // Верхняя строка: предмет + Liquid Glass капсула отвлечений
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column(
                    modifier = Modifier
                        .weight(1f)
                        .padding(end = 12.dp),
                    verticalArrangement = Arrangement.spacedBy(3.dp)
                ) {
                    Text(
                        text = snapshot.activeBlockTitle.ifBlank { "Фокус" },
                        style = MaterialTheme.typography.titleLarge,
                        color = StudyFlowColors.InkGraphite,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(6.dp)
                                .clip(CircleShape)
                                .background(snapshot.activeBlockTier.accentColor())
                        )
                        Text(
                            text = snapshot.activeBlockTier.cleanLabel(),
                            style = MaterialTheme.typography.labelMedium,
                            color = StudyFlowColors.SlateSecondary
                        )
                    }
                }

                LiquidGlassSurface(
                    shape = RoundedCornerShape(999.dp),
                    modifier = Modifier.clickable {
                        haptics.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                        onRegisterDistraction()
                    }
                ) {
                    Text(
                        text = "Отвлёкся · ${snapshot.distractionCount}",
                        style = MaterialTheme.typography.labelMedium.copy(
                            fontFeatureSettings = "tnum"
                        ),
                        color = StudyFlowColors.InkGraphite,
                        modifier = Modifier.padding(horizontal = 14.dp, vertical = 8.dp)
                    )
                }
            }

            // Центр: круглая Liquid Glass линза 270.dp с 2.dp дугой прогресса
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(20.dp)
            ) {
                Box(
                    modifier = Modifier.size(278.dp),
                    contentAlignment = Alignment.Center
                ) {
                    LiquidGlassSurface(
                        shape = CircleShape,
                        modifier = Modifier.size(270.dp)
                    ) {
                        Column(
                            modifier = Modifier.align(Alignment.Center),
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Text(
                                text = formatTimerSeconds(snapshot.remainingSeconds),
                                style = MaterialTheme.typography.displayLarge.copy(
                                    fontSize = 56.sp,
                                    lineHeight = 62.sp,
                                    fontWeight = FontWeight.Normal,
                                    letterSpacing = (-2.0).sp,
                                    fontFeatureSettings = "tnum"
                                ),
                                color = StudyFlowColors.InkGraphite
                            )
                            Text(
                                text = if (snapshot.isRunning) "Фокус" else "Пауза",
                                style = MaterialTheme.typography.labelMedium,
                                color = StudyFlowColors.SlateSecondary
                            )
                        }
                    }

                    // Ультратонкая 2.dp дуга прогресса по периметру линзы
                    Canvas(modifier = Modifier.size(274.dp)) {
                        val strokePx = 2.dp.toPx()
                        val inset = strokePx / 2f
                        val arcSize = Size(size.width - strokePx, size.height - strokePx)
                        val topLeft = Offset(inset, inset)

                        drawArc(
                            color = StudyFlowColors.ProgressTrack,
                            startAngle = -90f,
                            sweepAngle = 360f,
                            useCenter = false,
                            topLeft = topLeft,
                            size = arcSize,
                            style = Stroke(width = strokePx, cap = StrokeCap.Round)
                        )

                        drawArc(
                            color = StudyFlowColors.InkGraphite,
                            startAngle = -90f,
                            sweepAngle = 360f * snapshot.progressFraction.coerceIn(0f, 1f),
                            useCenter = false,
                            topLeft = topLeft,
                            size = arcSize,
                            style = Stroke(width = strokePx, cap = StrokeCap.Round)
                        )
                    }
                }

                // Мягкое появление подсказки при отвлечениях >= 2
                AnimatedVisibility(
                    visible = snapshot.earlyClosureRecommended,
                    enter = fadeIn() + slideInVertically { it / 3 },
                    exit = fadeOut() + slideOutVertically { it / 3 }
                ) {
                    LiquidGlassSurface(
                        shape = RoundedCornerShape(999.dp),
                        modifier = Modifier.clickable {
                            haptics.performHapticFeedback(HapticFeedbackType.LongPress)
                            onTriggerEarlyClosure()
                        }
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 18.dp, vertical = 11.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(6.dp)
                                    .clip(CircleShape)
                                    .background(StudyFlowColors.LoadPracticeAccent)
                            )
                            Text(
                                text = "Фокус падает · Закрыть мысль?",
                                style = MaterialTheme.typography.labelLarge,
                                color = StudyFlowColors.InkGraphite
                            )
                        }
                    }
                }
            }

            // Нижняя пара кнопок: графитовая «Пауза / Продолжить» и Liquid Glass «Завершить»
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 6.dp),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Button(
                    onClick = {
                        haptics.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                        if (snapshot.isRunning) onPause() else onResume()
                    },
                    modifier = Modifier
                        .weight(1.3f)
                        .height(52.dp),
                    shape = RoundedCornerShape(14.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = StudyFlowColors.InkGraphite,
                        contentColor = Color.White
                    ),
                    elevation = ButtonDefaults.buttonElevation(defaultElevation = 0.dp)
                ) {
                    if (snapshot.isRunning) {
                        PauseGlyph(color = Color.White)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "Пауза",
                            style = MaterialTheme.typography.labelLarge
                        )
                    } else {
                        Icon(
                            imageVector = Icons.Rounded.PlayArrow,
                            contentDescription = null,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "Продолжить",
                            style = MaterialTheme.typography.labelLarge
                        )
                    }
                }

                LiquidGlassSurface(
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier
                        .weight(1f)
                        .height(52.dp)
                        .clickable {
                            haptics.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                            showStopSheet = true
                        }
                ) {
                    Text(
                        text = "Завершить",
                        style = MaterialTheme.typography.labelLarge,
                        color = StudyFlowColors.InkGraphite,
                        modifier = Modifier.align(Alignment.Center)
                    )
                }
            }
        }
    }

    // Bottom Sheet подтверждения завершения вместо AlertDialog
    if (showStopSheet) {
        val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
        ModalBottomSheet(
            onDismissRequest = { showStopSheet = false },
            sheetState = sheetState,
            containerColor = StudyFlowColors.CanvasTop,
            contentColor = StudyFlowColors.InkGraphite,
            scrimColor = StudyFlowColors.InkGraphite.copy(alpha = 0.28f),
            shape = RoundedCornerShape(topStart = 24.dp, topEnd = 24.dp),
            dragHandle = { TimerSheetHandle() }
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .navigationBarsPadding()
                    .padding(horizontal = 20.dp, vertical = 14.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text(
                        text = "Завершить блок?",
                        style = MaterialTheme.typography.headlineSmall,
                        color = StudyFlowColors.InkGraphite
                    )
                    Text(
                        text = "Отработанное время сохранится, перерыв будет пропущен",
                        style = MaterialTheme.typography.bodyMedium,
                        color = StudyFlowColors.SlateSecondary
                    )
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    LiquidGlassSurface(
                        shape = RoundedCornerShape(14.dp),
                        modifier = Modifier
                            .weight(1f)
                            .height(48.dp)
                            .clickable { showStopSheet = false }
                    ) {
                        Text(
                            text = "Отмена",
                            style = MaterialTheme.typography.labelLarge,
                            color = StudyFlowColors.InkGraphite,
                            modifier = Modifier.align(Alignment.Center)
                        )
                    }

                    Button(
                        onClick = {
                            haptics.performHapticFeedback(HapticFeedbackType.LongPress)
                            showStopSheet = false
                            onStop()
                        },
                        modifier = Modifier
                            .weight(1f)
                            .height(48.dp),
                        shape = RoundedCornerShape(14.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = StudyFlowColors.DangerInk,
                            contentColor = Color.White
                        ),
                        elevation = ButtonDefaults.buttonElevation(defaultElevation = 0.dp)
                    ) {
                        Text(
                            text = "Завершить",
                            style = MaterialTheme.typography.labelLarge
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun ClosurePhaseScreen(
    snapshot: TimerSnapshot,
    initialClosureNote: String,
    onSaveClosureNote: (blockId: Long, note: String) -> Unit
) {
    val blockId = snapshot.activeBlockId
    var noteText by rememberSaveable(blockId) { mutableStateOf(initialClosureNote) }
    var lastSavedNote by remember(blockId) { mutableStateOf(initialClosureNote) }
    val latestNote by rememberUpdatedState(noteText)
    val latestSaveCallback by rememberUpdatedState(onSaveClosureNote)

    LaunchedEffect(blockId, noteText) {
        if (blockId != null && noteText != lastSavedNote) {
            delay(450L)
            latestSaveCallback(blockId, noteText)
            lastSavedNote = noteText
        }
    }

    DisposableEffect(blockId) {
        onDispose {
            if (blockId != null && latestNote.isNotBlank()) {
                latestSaveCallback(blockId, latestNote)
            }
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .metallicCanvasBackground()
            .statusBarsPadding()
            .navigationBarsPadding()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 20.dp, vertical = 28.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(24.dp)
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            Text(
                text = formatTimerSeconds(snapshot.remainingSeconds),
                style = MaterialTheme.typography.displayLarge.copy(
                    fontSize = 52.sp,
                    fontWeight = FontWeight.Normal,
                    letterSpacing = (-2.0).sp,
                    fontFeatureSettings = "tnum"
                ),
                color = StudyFlowColors.InkGraphite
            )
            Text(
                text = "Точка остановки",
                style = MaterialTheme.typography.labelLarge,
                color = StudyFlowColors.SlateSecondary
            )
        }

        // Центрированная металлическая панель без лишних рамок внутри
        MetallicSurface(
            shape = RoundedCornerShape(22.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(20.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(180.dp)
                ) {
                    if (noteText.isEmpty()) {
                        Text(
                            text = "На чём остановился и какой первый шаг завтра?",
                            style = MaterialTheme.typography.bodyLarge,
                            color = StudyFlowColors.SilverMuted
                        )
                    }
                    BasicTextField(
                        value = noteText,
                        onValueChange = { noteText = it },
                        modifier = Modifier.fillMaxSize(),
                        textStyle = MaterialTheme.typography.bodyLarge.copy(
                            color = StudyFlowColors.InkGraphite
                        ),
                        cursorBrush = SolidColor(StudyFlowColors.InkGraphite)
                    )
                }

                HorizontalDivider(
                    thickness = 0.5.dp,
                    color = StudyFlowColors.HairlineDivider
                )

                val statusText = when {
                    noteText.isBlank() -> "Автосохранение"
                    noteText == lastSavedNote -> "Сохранено"
                    else -> "Сохранение..."
                }
                Text(
                    text = statusText,
                    style = MaterialTheme.typography.labelSmall,
                    color = if (noteText.isNotBlank() && noteText == lastSavedNote) {
                        StudyFlowColors.LoadLightAccent
                    } else {
                        StudyFlowColors.SilverMuted
                    }
                )
            }
        }
    }
}

@Composable
private fun BreakPhaseScreen(
    snapshot: TimerSnapshot
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .metallicCanvasBackground(isBreakMode = true)
            .statusBarsPadding()
            .navigationBarsPadding()
            .padding(horizontal = 24.dp, vertical = 28.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.SpaceBetween
    ) {
        Text(
            text = "Перерыв",
            style = MaterialTheme.typography.titleMedium,
            color = StudyFlowColors.SlateSecondary
        )

        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Text(
                text = formatTimerSeconds(snapshot.remainingSeconds),
                style = MaterialTheme.typography.displayLarge.copy(
                    fontSize = 62.sp,
                    lineHeight = 68.sp,
                    fontWeight = FontWeight.Normal,
                    letterSpacing = (-2.0).sp,
                    fontFeatureSettings = "tnum"
                ),
                color = StudyFlowColors.InkGraphite
            )

            Box(
                modifier = Modifier
                    .width(156.dp)
                    .height(3.dp)
                    .clip(RoundedCornerShape(999.dp))
                    .background(StudyFlowColors.ProgressTrack)
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .fillMaxWidth(snapshot.progressFraction.coerceIn(0f, 1f))
                        .clip(RoundedCornerShape(999.dp))
                        .background(StudyFlowColors.LoadLightAccent)
                )
            }
        }

        // Единственная Liquid Glass карточка с кратким физиологическим советом (без кнопки пропуска)
        LiquidGlassSurface(
            shape = RoundedCornerShape(22.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(20.dp),
                verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(7.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(6.dp)
                            .clip(CircleShape)
                            .background(StudyFlowColors.LoadLightAccent)
                    )
                    Text(
                        text = "Восстановление",
                        style = MaterialTheme.typography.labelMedium,
                        color = StudyFlowColors.SlateSecondary
                    )
                }
                Text(
                    text = snapshot.breakRecommendation
                        ?: "Посмотрите вдаль через окно, пройдитесь и выпейте стакан воды.",
                    style = MaterialTheme.typography.bodyLarge,
                    color = StudyFlowColors.InkGraphite
                )
            }
        }
    }
}

@Composable
private fun PostCheckInScreen(
    snapshot: TimerSnapshot,
    onSubmitPostCheckIn: (blockId: Long, energyAfter: Int) -> Unit,
    onFallbackStop: () -> Unit
) {
    val haptics = LocalHapticFeedback.current
    var selectedEnergy by rememberSaveable { mutableIntStateOf(0) }
    val workedMinutes = (snapshot.elapsedWorkSeconds / 60.0).roundToInt()
        .coerceAtLeast(if (snapshot.elapsedWorkSeconds > 0) 1 else 0)

    Column(
        modifier = Modifier
            .fillMaxSize()
            .metallicCanvasBackground()
            .statusBarsPadding()
            .navigationBarsPadding()
            .padding(horizontal = 20.dp, vertical = 28.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.SpaceBetween
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            Text(
                text = "Уровень сил сейчас",
                style = MaterialTheme.typography.headlineMedium,
                color = StudyFlowColors.InkGraphite,
                textAlign = TextAlign.Center
            )
            Text(
                text = "${snapshot.activeBlockTitle.ifBlank { "Блок" }} · $workedMinutes мин",
                style = MaterialTheme.typography.bodyMedium.copy(fontFeatureSettings = "tnum"),
                color = StudyFlowColors.SlateSecondary,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }

        Column(
            modifier = Modifier.fillMaxWidth(),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                (1..5).forEach { level ->
                    val isSelected = selectedEnergy == level
                    val bgBrush = if (isSelected) {
                        Brush.verticalGradient(
                            listOf(StudyFlowColors.InkGraphite, StudyFlowColors.InkGraphite)
                        )
                    } else {
                        Brush.verticalGradient(
                            listOf(StudyFlowColors.MetalSurfaceTop, StudyFlowColors.MetalSurfaceBottom)
                        )
                    }

                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .height(64.dp)
                            .clip(RoundedCornerShape(16.dp))
                            .background(brush = bgBrush)
                            .border(
                                width = 0.75.dp,
                                color = if (isSelected) {
                                    StudyFlowColors.InkGraphite
                                } else {
                                    StudyFlowColors.MetalBorderBottom
                                },
                                shape = RoundedCornerShape(16.dp)
                            )
                            .clickable {
                                haptics.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                                selectedEnergy = level
                            },
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = level.toString(),
                            style = MaterialTheme.typography.headlineMedium.copy(
                                fontFeatureSettings = "tnum"
                            ),
                            color = if (isSelected) Color.White else StudyFlowColors.InkGraphite
                        )
                    }
                }
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = "1 · истощён",
                    style = MaterialTheme.typography.labelSmall,
                    color = StudyFlowColors.SilverMuted
                )
                Text(
                    text = "5 · полон сил",
                    style = MaterialTheme.typography.labelSmall,
                    color = StudyFlowColors.SilverMuted
                )
            }
        }

        Button(
            onClick = {
                haptics.performHapticFeedback(HapticFeedbackType.LongPress)
                val blockId = snapshot.activeBlockId
                if (blockId != null && selectedEnergy in 1..5) {
                    onSubmitPostCheckIn(blockId, selectedEnergy)
                } else {
                    onFallbackStop()
                }
            },
            enabled = selectedEnergy in 1..5,
            modifier = Modifier
                .fillMaxWidth()
                .height(52.dp),
            shape = RoundedCornerShape(14.dp),
            colors = ButtonDefaults.buttonColors(
                containerColor = StudyFlowColors.InkGraphite,
                contentColor = Color.White,
                disabledContainerColor = StudyFlowColors.ProgressTrack,
                disabledContentColor = StudyFlowColors.SilverMuted
            ),
            elevation = ButtonDefaults.buttonElevation(defaultElevation = 0.dp)
        ) {
            Text(
                text = "Готово",
                style = MaterialTheme.typography.labelLarge
            )
        }
    }
}

@Composable
private fun TimerSheetHandle() {
    Box(
        modifier = Modifier
            .padding(top = 10.dp, bottom = 6.dp)
            .width(34.dp)
            .height(4.dp)
            .clip(RoundedCornerShape(999.dp))
            .background(StudyFlowColors.MetalBorderBottom)
    )
}

@Composable
private fun PauseGlyph(color: Color) {
    Canvas(modifier = Modifier.size(15.dp)) {
        val barWidth = size.width * 0.27f
        val barHeight = size.height * 0.80f
        val topOffset = (size.height - barHeight) / 2f
        val radius = CornerRadius(1.5.dp.toPx(), 1.5.dp.toPx())

        drawRoundRect(
            color = color,
            topLeft = Offset(size.width * 0.16f, topOffset),
            size = Size(barWidth, barHeight),
            cornerRadius = radius
        )
        drawRoundRect(
            color = color,
            topLeft = Offset(size.width * 0.57f, topOffset),
            size = Size(barWidth, barHeight),
            cornerRadius = radius
        )
    }
}

private fun formatTimerSeconds(totalSeconds: Int): String {
    val safe = totalSeconds.coerceAtLeast(0)
    val minutes = safe / 60
    val seconds = safe % 60
    return String.format(Locale.US, "%02d:%02d", minutes, seconds)
}
