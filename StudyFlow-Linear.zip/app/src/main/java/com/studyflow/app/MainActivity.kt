// ПУТЬ: com/studyflow/app/MainActivity.kt

package com.studyflow.app

import android.Manifest
import android.content.pm.PackageManager
import android.graphics.Color
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.core.content.ContextCompat
import com.studyflow.app.domain.model.TimerPhase
import com.studyflow.app.service.TimerForegroundService
import com.studyflow.app.ui.screens.ActiveTimerScreen
import com.studyflow.app.ui.screens.DashboardScreen
import com.studyflow.app.ui.theme.StudyFlowTheme
import com.studyflow.app.ui.viewmodel.StudyViewModel
import com.studyflow.app.ui.viewmodel.StudyViewModelFactory

/**
 * Главная Activity приложения StudyFlow.
 *
 * - Запрашивает разрешение `POST_NOTIFICATIONS` на Android 13+ (API 33+).
 * - Подключает строгую тёмную тему [StudyFlowTheme].
 * - Автоматически переключает UI между [DashboardScreen] и [ActiveTimerScreen]
 *   в зависимости от текущей фазы [TimerPhase].
 */
class MainActivity : ComponentActivity() {

    private val viewModel: StudyViewModel by viewModels {
        StudyViewModelFactory(applicationContext)
    }

    private val notificationPermissionLauncher =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) {
            // Приложение продолжает работу офлайн независимо от решения пользователя;
            // сервис безопасно обрабатывает отсутствие разрешения на уведомления.
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.dark(Color.TRANSPARENT),
            navigationBarStyle = SystemBarStyle.dark(Color.TRANSPARENT)
        )

        requestNotificationPermissionIfNeeded()

        setContent {
            StudyFlowTheme {
                val uiState by viewModel.uiState.collectAsState()

                if (uiState.timerSnapshot.phase != TimerPhase.IDLE) {
                    ActiveTimerScreen(
                        snapshot = uiState.timerSnapshot,
                        initialClosureNote = uiState.activeBlock?.closureNote.orEmpty(),
                        onPause = {
                            viewModel.sendTimerCommand(
                                context = this,
                                action = TimerForegroundService.ACTION_PAUSE
                            )
                        },
                        onResume = {
                            viewModel.sendTimerCommand(
                                context = this,
                                action = TimerForegroundService.ACTION_RESUME
                            )
                        },
                        onRegisterDistraction = {
                            viewModel.sendTimerCommand(
                                context = this,
                                action = TimerForegroundService.ACTION_REGISTER_DISTRACTION
                            )
                        },
                        onTriggerEarlyClosure = {
                            viewModel.sendTimerCommand(
                                context = this,
                                action = TimerForegroundService.ACTION_TRIGGER_EARLY_CLOSURE
                            )
                        },
                        onStop = {
                            viewModel.sendTimerCommand(
                                context = this,
                                action = TimerForegroundService.ACTION_STOP
                            )
                        },
                        onSaveClosureNote = { blockId, note ->
                            viewModel.saveClosureNote(blockId = blockId, note = note)
                        },
                        onSubmitPostCheckIn = { blockId, energyAfter ->
                            viewModel.submitPostCheckIn(
                                blockId = blockId,
                                energyAfter = energyAfter
                            )
                        }
                    )
                } else {
                    DashboardScreen(
                        uiState = uiState,
                        onSaveMorningSleep = { sleepQuality ->
                            viewModel.saveMorningSleepCheckIn(sleepQuality)
                        },
                        onAddBlock = { title, tier, plannedMinutes ->
                            viewModel.addStudyBlock(
                                title = title,
                                tier = tier,
                                plannedMinutes = plannedMinutes
                            )
                        },
                        onDeleteBlock = { block ->
                            viewModel.deleteStudyBlock(block)
                        },
                        onStartBlock = { block, energyBefore ->
                            viewModel.startBlock(
                                context = this,
                                block = block,
                                energyBefore = energyBefore
                            )
                        },
                        onApplyEnergyAdaptation = { blocks ->
                            viewModel.applyEnergyAdaptation(blocks)
                        },
                        onDismissSnackbar = {
                            viewModel.clearSnackbarMessage()
                        }
                    )
                }
            }
        }
    }

    override fun onResume() {
        super.onResume()
        viewModel.refreshDateIfNeeded()
    }

    private fun requestNotificationPermissionIfNeeded() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.TIRAMISU) return

        val isGranted = ContextCompat.checkSelfPermission(
            this,
            Manifest.permission.POST_NOTIFICATIONS
        ) == PackageManager.PERMISSION_GRANTED

        if (!isGranted) {
            notificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
    }
}
